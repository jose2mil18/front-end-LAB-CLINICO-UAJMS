import { Component } from '@angular/core';
import { ViewEncapsulation } from '@angular/core';
import { Http } from '@angular/http';
import { Response } from '@angular/http';

declare var Stimulsoft: any;

@Component({
	selector: 'app-root',
	template: `<div>
					<h2>Stimulsoft Reports.JS - TicketsStatistics.mrt - Viewer</h2>
					<div id="viewerContent"></div>
				</div>`,
	encapsulation: ViewEncapsulation.None
})

export class AppComponent {
	options: any = new Stimulsoft.Viewer.StiViewerOptions();
	viewer: any = new Stimulsoft.Viewer.StiViewer(this.options, 'StiViewer', false);

	ngOnInit() {
		var report = Stimulsoft.Report.StiReport.createNewDashboard();
		report.loadFile("reports/TicketsStatistics.mrt");

		this.viewer.report = report;
		this.viewer.renderHtml("viewerContent");
	}

	constructor(private http: Http) {

	}
}